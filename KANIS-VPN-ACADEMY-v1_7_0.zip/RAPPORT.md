# Rapport — KANIS VPN ACADEMY v1.7.0 (reprise de la v1.6.1)

## 1. Problèmes détectés dans la v1.6.1
| # | Problème | Gravité |
|---|---|---|
| 1 | Erreur « Configuration manquante » affichée pour **trois causes différentes** (config absente, bibliothèque absente, clé invalide) : impossible de savoir laquelle | Haute |
| 2 | `supabase/config.toml`, README et ancien rapport visaient le projet `qoxsvtzjqprwzegbsnhv`, alors que `config.js` vise `lqxkkyhinkxncagwkojn` | Haute |
| 3 | Aucune table, fonction ni écran de **retraits** (demande, validation, refus, historique) | Haute |
| 4 | Paiement uniquement « envoie au numéro + capture » : **aucune vérification automatique** ; webhook générique, sans format de prestataire, sans contrôle du montant, sans journal | Haute |
| 5 | Opérateurs limités à Orange Money / **Wave** (compatibilité Burkina Faso non confirmée) ; pas de Moov Money | Haute |
| 6 | Migration 001 non réexécutable ; plusieurs fonctions exécutables par `anon` (droits par défaut) | Moyenne |
| 7 | `confirm_payment` : confirmation admin possible sans référence ; test du rôle via `auth.role()` seul | Moyenne |
| 8 | Aucune validation des réglages (`reseller_share_percent` pouvait dépasser 100 ou être non numérique) | Moyenne |
| 9 | Admin : impossible de voir d'un coup d'œil actifs / inactifs / activation payée ou non | Moyenne |
| 10 | Workflow : pas de contrôle du contenu de `supabase.js` ni de l'APK ; `copy-vendor.js` ne validait pas le fichier copié | Moyenne |
| 11 | Aucun test automatique dans le dépôt | Moyenne |

## 2. Corrections réalisées
- **Diagnostic de configuration** (`kanis-backend.js`) : messages distincts — « Configuration manquante » (config.js sans url/clé), « URL Supabase invalide » (http / localhost), « Clé interdite » (`sb_secret_` / `service_role`), « Bibliothèque manquante » (supabase.js non généré, avec la commande à lancer). Test réseau au démarrage (`/auth/v1/settings`) : serveur injoignable / clé refusée (401-403) / URL introuvable (404) / inscriptions désactivées / confirmation e-mail encore exigée.
- **Projet unique** : `config.toml`, README et rapport alignés sur `lqxkkyhinkxncagwkojn` ; `npm run verify` contrôle que `config.js` et `config.toml` coïncident.
- **Migration `004`** (réexécutable) : opérateurs `orange_money` / `moov_money` ; colonnes `provider_txn`, `checkout_url`, `failure_reason` ; table `payment_events` (journal idempotent, sans donnée personnelle) ; `fail_payment` ; `confirm_payment` durci (référence obligatoire pour l'admin, rôle `service_role` via le JWT, idempotent) ; table `withdrawals` + `request_withdrawal` (solde débité à la demande, verrou de ligne, une demande en attente à la fois, minimum configurable, numéro burkinabè 8 chiffres) + `admin_process_withdrawal` (acceptation / refus avec recrédit) ; `admin_resellers` (actifs/inactifs, activation payée) ; validation des réglages ; retrait des droits `anon` sur les fonctions sensibles.
- **Edge Functions** : `create-payment` (JWT utilisateur, vérifie que le paiement appartient à l'appelant, montant multiple de 5, pas de seconde transaction pour le même paiement), `payment-webhook` réécrit (x-token HMAC en temps constant → site → contrôle serveur à serveur → montant/devise → `confirm_payment`), `notify-email` (Resend).
- **Application** : opérateurs Orange Money (BF) et Moov Money (BF) à la place de Wave ; bouton « PAYER MAINTENANT » qui ouvre le lien CinetPay ; onglet **Retraits** revendeur ; onglets **Revendeurs** (actifs / inactifs, activation payée ou NON payée, solde, ventes) et **Retraits** administrateur ; confirmation manuelle marquée « secours ».
- **Build** : `copy-vendor.js` valide le fichier ; `verify-config.js` ; workflow strict (`bash -eo pipefail`), contrôle de `supabase.js` avant et après `cap sync`, et dans l'APK (présence de `supabase.js`, URL du projet, absence de localhost / clé secrète) ; plugin `@capacitor/browser` pour ouvrir le paiement.

## 3. Tests réellement exécutés (dans cet environnement)
| Test | Résultat |
|---|---|
| `node --check` sur `kanis-backend.js` | OK |
| `npm run verify` : format de `config.js`, URL https non locale, clé `sb_publishable_…`, même projet que `config.toml`, aucune clé secrète dans `www/`, ordre des scripts | OK (5/5) |
| `verify --vendor` | **ÉCHEC attendu ici** : `www/js/vendor/supabase.js` n'existe pas (pas de `npm install`, réseau coupé) |
| Syntaxe TypeScript des 4 fichiers d'Edge Functions (transpilation) | OK |
| Workflow YAML valide (15 étapes) | OK |
| SQL : 27 fonctions recensées, tous les `grant/revoke` de 004 visent une fonction existante, `$$`/parenthèses/apostrophes équilibrés, toutes les tables et RPC utilisées par l'app existent dans les migrations | OK (contrôle **statique**) |
| `tests/hmac.test.js` : ordre de concaténation, HMAC-SHA256 = Node `crypto`, falsification détectée, comparaison en temps constant, id de transaction | 7/7 OK — teste **mon implémentation**, pas CinetPay |
| `tests/ui.test.js` (Chromium headless) : diagnostics réels (bibliothèque absente, config vide, localhost, clé `sb_secret_`) | 5/5 OK |
| `tests/ui.test.js`, scénarios D avec **client Supabase SIMULÉ** : page d'activation, choix Orange/Moov sans Wave, appels `request_activation` puis `create-payment`, onglet Retraits revendeur, vues admin Revendeurs et Retraits, aucune erreur JavaScript | 12/12 OK — teste l'**interface seulement**, pas le serveur |

## 4. NON testé (aucune preuve d'exécution)
- **Aucun appel réel à Supabase** : le réseau du bac à sable est bloqué. Rien n'a été vérifié contre ton projet : URL, clé, authentification, session, tables, RPC, RLS, CORS, inscription / connexion / récupération de mot de passe.
- **Migrations SQL 001–004 jamais exécutées** (pas de PostgreSQL) : seul un contrôle statique a été fait. Exécute-les dans l'ordre et envoie-moi toute erreur.
- **`npm install`, `npm run vendor`, `cap sync`, Gradle, APK** : non exécutés (pas de réseau, pas de SDK Android). **Aucun APK n'a été compilé ici** ; le workflow GitHub est la voie prévue.
- **CinetPay** : endpoints et ordre du x-token repris de la documentation officielle (pages « initialisation », « notification », « x-token HMAC »), mais **aucun appel réel** (pas de compte marchand ni de clés). Les Edge Functions n'ont jamais tourné sous Deno.
- Envoi réel d'e-mails (SMTP, Resend), notifications Android, lien profond sur téléphone, installation et lancement de l'APK.

## 5. Ce qui nécessite encore ton intervention
1. Exécuter `001` → `004` dans le SQL Editor ; créer l'administrateur (`update public.profiles set role='admin' where email='…'`).
2. Supabase → Authentication : désactiver « Confirm email » ; ajouter `kanisvpn://auth-callback` aux URL de redirection ; configurer un SMTP personnalisé.
3. Créer un compte marchand **CinetPay** (activer Orange Money BF et Moov Money BF), récupérer API key, Site ID, clé secrète HMAC, puis définir les secrets listés dans le README et déployer les 3 fonctions.
4. Héberger `docs/paiement-retour.html` (GitHub Pages) et renseigner `PAYMENT_RETURN_URL`.
5. Vérifier que `confirm_payment` accepte l'appel du webhook : si tu utilises une clé « secret » au nouveau format (`sb_secret_…`) dans l'Edge Function, confirme que le rôle `service_role` est bien présent dans le JWT — sinon dis-le-moi.
6. Pousser sur GitHub (branche `main`) : le workflow produit l'artefact `KANIS-VPN-ACADEMY-APK` ; envoie-moi le journal en cas d'échec.
7. Décider du sort de la **page d'accueil publique** (`www/index.html`) : elle propose encore le paiement manuel Orange Money / Wave par WhatsApp avec preuve (numéros dans `CONFIG`). Je ne l'ai pas modifiée (design préservé) ; ce flux ne valide rien automatiquement, mais mentionne Wave.
8. Versements de retraits : l'administrateur envoie lui-même l'argent puis clique « Accepter » ; l'automatisation (API de transfert CinetPay) n'est pas faite.
9. Montants : CinetPay exige des multiples de 5 ; une promotion produisant un autre montant sera refusée avec un message clair.

## 6. Secrets serveur à configurer (jamais dans le code public)
`CINETPAY_API_KEY`, `CINETPAY_SITE_ID`, `CINETPAY_SECRET_KEY`, `PAYMENT_RETURN_URL`, (`PAYMENT_NOTIFY_URL`), `RESEND_API_KEY`, `EMAIL_FROM`, `EMAIL_WEBHOOK_SECRET`. `SUPABASE_URL`, `SUPABASE_ANON_KEY` et `SUPABASE_SERVICE_ROLE_KEY` sont fournis automatiquement aux Edge Functions.
