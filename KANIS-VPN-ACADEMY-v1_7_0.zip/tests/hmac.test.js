// Test unitaire de MON implémentation HMAC / égalité en temps constant (transpilée depuis _shared/cinetpay.ts).
// Ce n'est PAS un test contre CinetPay : le jeu de données est fabriqué ici.
const ts=require('/opt/npm-tools/node_modules/typescript'),fs=require('fs'),crypto=require('crypto');
const js=ts.transpileModule(fs.readFileSync(require('path').join(__dirname,'..','supabase','functions','_shared','cinetpay.ts'),'utf8'),{compilerOptions:{module:'CommonJS',target:'ES2022'}}).outputText;
const m={exports:{}};new Function('module','exports','crypto',js)(m,m.exports,globalThis.crypto||crypto.webcrypto);
const {hmacSha256Hex,hmacInput,safeEqual,txnFromPayment}=m.exports;
let fail=0;const t=(n,c)=>{console.log((c?'OK  ':'ERR ')+n);if(!c)fail++;};
(async()=>{
 const f={cpm_site_id:'123456',cpm_trans_id:'K0123456789abcdef0123456789a',cpm_trans_date:'2026-11-04 10:00:00',cpm_amount:'3000',cpm_currency:'XOF',signature:'abc',payment_method:'OMBF',cel_phone_num:'70000000',cpm_phone_prefixe:'226',cpm_language:'fr',cpm_version:'V2',cpm_payment_config:'SINGLE',cpm_page_action:'PAYMENT',cpm_custom:'',cpm_designation:'Activation',cpm_error_message:'SUCCES'};
 const secret='cle_de_test';
 const data=Object.values(f).join('');           // même ordre que la doc (objet construit dans cet ordre)
 t('ordre de concaténation = ordre documenté',hmacInput(f)===data);
 const expect=crypto.createHmac('sha256',secret).update(data).digest('hex');
 t('HMAC-SHA256 identique à Node crypto',await hmacSha256Hex(secret,hmacInput(f))===expect);
 const g={...f,cpm_amount:'1'};
 t('un montant modifié change le token (falsification détectée)',await hmacSha256Hex(secret,hmacInput(g))!==expect);
 t('safeEqual : égal',safeEqual(expect,expect));
 t('safeEqual : différent',!safeEqual(expect,expect.slice(0,-1)+(expect.slice(-1)==='0'?'1':'0')));
 t('safeEqual : longueurs différentes',!safeEqual('ab','abc'));
 const id='123e4567-e89b-12d3-a456-426614174000';
 t('identifiant de transaction alphanumérique (29 car.)',/^K[0-9a-f]{28}$/.test(txnFromPayment(id)));
 process.exit(fail?1:0);
})();
