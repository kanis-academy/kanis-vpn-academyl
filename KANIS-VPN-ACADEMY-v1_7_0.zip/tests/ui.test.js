// Tests d'interface (Chromium headless, fichiers locaux). IMPORTANT :
//  - scénarios A-C : réels (aucun faux client) -> messages de diagnostic de configuration ;
//  - scénario D : client Supabase SIMULÉ (stub) -> teste uniquement le code de l'interface, PAS le serveur Supabase.
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const path = require('path'), fs = require('fs');
const WWW = path.join(__dirname, '..', 'www'), URL = 'file://' + WWW + '/index.html';
let fail = 0; const t = (n, c, extra) => { console.log((c ? 'OK  ' : 'ERR ') + n + (c ? '' : '  -> ' + (extra || ''))); if (!c) fail++; };
const text = (p) => p.evaluate(() => document.querySelector('.kv') ? document.querySelector('.kv').innerText : '');

const STUB = (scenario) => `
(function(){
  var S=${JSON.stringify(scenario)};
  window.__calls=[];
  function builder(table){var st={table:table,filters:[]};var b={};
    ['select','eq','in','gt','order','limit','insert','update','delete','neq'].forEach(function(m){b[m]=function(){return b;};});
    var res=function(){var d=(S.tables||{})[table];return {data:d===undefined?[]:d,error:null};};
    b.maybeSingle=function(){var r=res();return Promise.resolve({data:Array.isArray(r.data)?(r.data[0]||null):r.data,error:null});};
    b.single=b.maybeSingle;
    b.then=function(ok,ko){return Promise.resolve(res()).then(ok,ko);};
    return b;}
  var ch={on:function(){return ch;},subscribe:function(){return ch;}};
  window.supabase={createClient:function(){return{
    auth:{getSession:function(){return Promise.resolve({data:{session:S.session}});},
      onAuthStateChange:function(){return{data:{subscription:{unsubscribe:function(){}}}};},signOut:function(){return Promise.resolve({});}},
    from:builder,
    rpc:function(n,a){window.__calls.push({rpc:n,args:a});var v=(S.rpc||{})[n];if(v&&v.error)return Promise.resolve({data:null,error:{message:v.error}});return Promise.resolve({data:v===undefined?null:v,error:null});},
    functions:{invoke:function(n,o){window.__calls.push({fn:n,body:o&&o.body});return Promise.resolve({data:{payment_url:'https://pay.example.test/x'},error:null});}},
    channel:function(){return ch;},removeChannel:function(){}};}};
})();`;

(async () => {
  const br = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1243/chrome-linux64/chrome', args: ['--no-sandbox', '--allow-file-access-from-files'] });
  async function open(opts) {
    const ctx = await br.newContext(); const page = await ctx.newPage(); const errors = [];
    page.on('pageerror', (e) => errors.push(e.message));
    await page.route('**/js/vendor/supabase.js', (r) => opts.stub ? r.fulfill({ contentType: 'text/javascript', body: STUB(opts.stub) }) : r.abort());
    if (opts.config !== undefined) await page.route('**/js/config.js', (r) => r.fulfill({ contentType: 'text/javascript', body: opts.config }));
    await page.route('https://**', (r) => r.abort());            // aucun accès réseau réel
    await page.goto(URL); await page.waitForTimeout(opts.wait || 2200);
    return { page, errors, ctx };
  }

  // A. bibliothèque absente (état actuel du dépôt : vendor/ non généré) -> message précis
  let r = await open({}); let x = await text(r.page);
  t('A. bibliothèque absente -> « Bibliothèque manquante » + consigne npm run vendor', /Bibliothèque manquante/.test(x) && /npm run vendor/.test(x), x.slice(0, 200));
  t('A. ne dit plus « Configuration manquante » quand seule la bibliothèque manque', !/Configuration manquante/.test(x));
  await r.ctx.close();
  // B. config absente
  r = await open({ config: '/* vide */' }); x = await text(r.page);
  t('B. config.js vide -> « Configuration manquante »', /Configuration manquante/.test(x)); await r.ctx.close();
  // C. localhost / clé secrète
  r = await open({ config: 'window.KANIS_SUPABASE={url:"http://localhost:54321",anonKey:"sb_publishable_xxxxxxxxxxxxxxxxxxxxxxxx"};' }); x = await text(r.page);
  t('C. URL localhost refusée', /URL Supabase invalide/.test(x)); await r.ctx.close();
  r = await open({ config: 'window.KANIS_SUPABASE={url:"https://abc.supabase.co",anonKey:"sb_secret_abcdefghijklmnop"};' }); x = await text(r.page);
  t('C. clé sb_secret_ refusée', /Clé interdite/.test(x)); await r.ctx.close();

  // D. interface avec client SIMULÉ
  const me = { user: { id: 'u1' } };
  const base = { session: { user: me.user } };
  // D1 revendeur inactif
  r = await open({ stub: { ...base, tables: { profiles: [{ id: 'u1', role: 'reseller', reseller_status: 'pending', full_name: 'Test', email: 't@t.t', balance: 0 }], orders: [], payments: [{ id: 'p1', status: 'pending' }] }, rpc: { activation_quote: { base: 3000, final: 3000 }, request_activation: 'order-1', my_access: [] } } });
  x = await text(r.page);
  t('D1. revendeur inactif -> page d’activation, INACTIF', /Activation du compte revendeur/.test(x) && /INACTIF/.test(x), x.slice(0, 200));
  t('D1. toast serveur injoignable affiché (test réseau réel, réseau coupé)', await r.page.evaluate(() => /injoignable/i.test(document.body.innerText)), 'toast absent');
  const opts = await r.page.evaluate(() => [...document.querySelectorAll('.kv select option')].map((o) => o.textContent));
  t('D1. opérateurs = Orange Money + Moov Money (Burkina), sans Wave', opts.some((o) => /Orange Money/.test(o)) && opts.some((o) => /Moov Money/.test(o)) && !opts.some((o) => /Wave/.test(o)), JSON.stringify(opts));
  await r.page.selectOption('.kv select', 'moov_money'); await r.page.click('.kv button[type=submit]'); await r.page.waitForTimeout(600);
  const calls = await r.page.evaluate(() => window.__calls);
  t('D1. request_activation appelé avec moov_money', calls.some((c) => c.rpc === 'request_activation' && c.args.p_provider === 'moov_money'), JSON.stringify(calls));
  t('D1. create-payment appelé ensuite (lien de paiement côté serveur)', calls.some((c) => c.fn === 'create-payment'), JSON.stringify(calls));
  t('D1. aucune erreur JavaScript', r.errors.length === 0, r.errors.join('|')); await r.ctx.close();
  // D2 revendeur actif : onglet Retraits
  r = await open({ stub: { ...base, tables: { profiles: [{ id: 'u1', role: 'reseller', reseller_status: 'active', full_name: 'Rev', email: 'r@t.t', balance: 4500, phone: '70000000' }], courses: [], orders: [], commissions: [], withdrawals: [{ id: 'w1', amount: 1000, method: 'orange_money', status: 'refused', admin_note: 'Numéro incorrect', created_at: '2026-11-01T10:00:00Z' }] }, rpc: { my_access: [], request_withdrawal: 'w2' } } });
  await r.page.click('.kv .tabs button:has-text("Retraits")'); await r.page.waitForTimeout(500); x = await text(r.page);
  t('D2. onglet Retraits : solde et historique visibles', /Solde disponible/.test(x) && /4\s?500/.test(x) && /Refusé/.test(x) && /Numéro incorrect/.test(x), x.slice(0, 300));
  await r.page.fill('.kv input[type=number]', '2000'); await r.page.click('.kv button:has-text("DEMANDER LE RETRAIT")'); await r.page.waitForTimeout(500);
  t('D2. request_withdrawal(2000, orange_money, 70000000)', (await r.page.evaluate(() => window.__calls)).some((c) => c.rpc === 'request_withdrawal' && c.args.p_amount === 2000 && c.args.p_method === 'orange_money' && c.args.p_phone === '70000000'));
  t('D2. aucune erreur JavaScript', r.errors.length === 0, r.errors.join('|')); await r.ctx.close();
  // D3 admin : revendeurs actifs / inactifs + retraits
  r = await open({ stub: { ...base, tables: { profiles: [{ id: 'u1', role: 'admin', full_name: 'Admin', email: 'a@t.t' }], notifications: [], withdrawals: [{ id: 'w9', amount: 3000, method: 'moov_money', phone: '60000000', status: 'pending', profiles: { full_name: 'Rev Un' }, created_at: '2026-11-02T10:00:00Z' }] },
    rpc: { my_access: [], admin_stats: { buyers: 1, resellers: 2, sales: 0, revenue: 0, commissions: 0, academy: 0 },
      admin_resellers: [{ user_id: 'r1', full_name: 'Rev Inactif', email: 'i@t.t', status: 'pending', activation_paid: false, balance_fcfa: 0, sales_count: 0 }, { user_id: 'r2', full_name: 'Rev Actif', email: 'a@t.t', status: 'active', activation_paid: true, balance_fcfa: 900, sales_count: 3 }], admin_process_withdrawal: null } } });
  await r.page.click('.kv .tabs button:has-text("Revendeurs")'); await r.page.waitForTimeout(500); x = await text(r.page);
  t('D3. admin : 1 actif / 1 inactif, activation payée / NON payée', /1 actif\(s\)/.test(x) && /1 inactif\(s\)/.test(x) && /NON payée/.test(x) && /payée ✓/.test(x), x.slice(0, 400));
  await r.page.click('.kv .tabs button:has-text("Retraits")'); await r.page.waitForTimeout(500); x = await text(r.page);
  t('D3. admin : demande de retrait en attente avec Accepter / Refuser', /Rev Un/.test(x) && /Accepter/.test(x) && /Refuser/.test(x), x.slice(0, 300));
  t('D3. aucune erreur JavaScript', r.errors.length === 0, r.errors.join('|')); await r.ctx.close();
  await br.close(); process.exit(fail ? 1 : 0);
})();
