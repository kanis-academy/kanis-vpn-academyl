// Clé publique Supabase (conçue pour être dans l'app) ; la sécurité repose sur les règles RLS des migrations.
// Ne jamais placer une clé service_role ou sb_secret_ dans l'application.
window.KANIS_SUPABASE = {
  url: "https://lqxkkyhinkxncagwkojn.supabase.co",
  anonKey: "sb_publishable_XRqjv0eufs4q0nEWaYHBrQ_41DMM3Hy",
  redirectTo: "" // Web : origine de l’application ; Android : lien profond kanisvpn://auth-callback
};
