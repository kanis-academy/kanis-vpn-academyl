// Outils CinetPay partagés (API « checkout » v2 — https://docs.cinetpay.com/api/1.0-fr/checkout/initialisation).
// Opérateurs Burkina Faso listés par la documentation officielle CinetPay : OMBF (Orange Money BF), MOOVBF (Moov Money BF).
export const CINETPAY_BASE = "https://api-checkout.cinetpay.com/v2";

const enc = new TextEncoder();
export const hex = (b: ArrayBuffer) => Array.from(new Uint8Array(b)).map((x) => x.toString(16).padStart(2, "0")).join("");

export async function hmacSha256Hex(secret: string, data: string): Promise<string> {
  const key = await crypto.subtle.importKey("raw", enc.encode(secret), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
  return hex(await crypto.subtle.sign("HMAC", key, enc.encode(data)));
}

// Comparaison en temps constant (évite de révéler le token par le temps de réponse).
export function safeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

// Ordre de concaténation décrit par la documentation « x-token HMAC » de CinetPay.
export const HMAC_FIELDS = [
  "cpm_site_id", "cpm_trans_id", "cpm_trans_date", "cpm_amount", "cpm_currency", "signature",
  "payment_method", "cel_phone_num", "cpm_phone_prefixe", "cpm_language", "cpm_version",
  "cpm_payment_config", "cpm_page_action", "cpm_custom", "cpm_designation", "cpm_error_message",
];
export const hmacInput = (f: Record<string, string>) => HMAC_FIELDS.map((k) => f[k] ?? "").join("");

// Identifiant de transaction envoyé à CinetPay : dérivé de l'UUID du paiement (lettres/chiffres uniquement).
export const txnFromPayment = (paymentId: string) => "K" + paymentId.replace(/-/g, "").slice(0, 28);
