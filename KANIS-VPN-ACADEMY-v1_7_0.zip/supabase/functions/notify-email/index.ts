// Edge Function : envoie par e-mail les notifications importantes (paiement, commission, retrait, activation).
// Branchement : Supabase → Database → Webhooks → table « notifications », événement INSERT → cette fonction,
// avec l'en-tête HTTP « x-webhook-secret » = EMAIL_WEBHOOK_SECRET. Déploiement : supabase functions deploy notify-email --no-verify-jwt
// Secrets : RESEND_API_KEY, EMAIL_FROM (adresse d'un domaine vérifié chez Resend), EMAIL_WEBHOOK_SECRET.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";
import { safeEqual } from "../_shared/cinetpay.ts";

Deno.serve(async (req) => {
  if (req.method !== "POST") return new Response("méthode non autorisée", { status: 405 });
  const secret = Deno.env.get("EMAIL_WEBHOOK_SECRET"), key = Deno.env.get("RESEND_API_KEY"), from = Deno.env.get("EMAIL_FROM");
  if (!secret || !key || !from) return new Response("non configuré", { status: 503 });
  if (!safeEqual(req.headers.get("x-webhook-secret") ?? "", secret)) return new Response("non autorisé", { status: 401 });
  try {
    const ev = await req.json();
    const rec = ev?.record;
    if (ev?.type !== "INSERT" || !rec?.user_id) return new Response("ignoré");      // les messages « pour tous » ne sont pas envoyés par e-mail
    const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
    const { data: p } = await db.from("profiles").select("email").eq("id", rec.user_id).maybeSingle();
    if (!p?.email) return new Response("pas d'e-mail");
    const r = await fetch("https://api.resend.com/emails", {
      method: "POST", headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
      body: JSON.stringify({ from, to: [p.email], subject: `KANIS VPN ACADEMY — ${String(rec.title ?? "Notification").slice(0, 120)}`, text: String(rec.body ?? "") }),
    });
    if (!r.ok) { console.error("resend", r.status); return new Response("échec d'envoi", { status: 502 }); }
    return new Response("ok");
  } catch (e) {
    console.error("notify-email", (e as Error).message);
    return new Response("erreur serveur", { status: 500 });
  }
});
