// Edge Function : crée le lien de paiement CinetPay (Orange Money BF / Moov Money BF) pour un paiement « pending ».
// Appelée par l'application avec la session de l'utilisateur (JWT). Aucune clé secrète n'est exposée au client.
// Secrets : CINETPAY_API_KEY, CINETPAY_SITE_ID, PAYMENT_RETURN_URL (page https de retour), PAYMENT_NOTIFY_URL (optionnel).
// SUPABASE_URL, SUPABASE_ANON_KEY et SUPABASE_SERVICE_ROLE_KEY sont fournis automatiquement par Supabase.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";
import { CINETPAY_BASE, txnFromPayment } from "../_shared/cinetpay.ts";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (o: unknown, status = 200) => new Response(JSON.stringify(o), { status, headers: { ...CORS, "Content-Type": "application/json" } });
const clean = (s: string, n: number) => (s || "").replace(/[^\p{L}\p{N} '-]/gu, "").trim().slice(0, n);

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });
  if (req.method !== "POST") return json({ error: "Méthode non autorisée" }, 405);
  try {
    const url = Deno.env.get("SUPABASE_URL")!, anon = Deno.env.get("SUPABASE_ANON_KEY")!, svc = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const apikey = Deno.env.get("CINETPAY_API_KEY"), siteId = Deno.env.get("CINETPAY_SITE_ID"), ret = Deno.env.get("PAYMENT_RETURN_URL");
    if (!apikey || !siteId || !ret) return json({ error: "Paiement en ligne non configuré côté serveur (CINETPAY_API_KEY, CINETPAY_SITE_ID, PAYMENT_RETURN_URL)." }, 503);
    const notify = Deno.env.get("PAYMENT_NOTIFY_URL") ?? `${url}/functions/v1/payment-webhook`;

    // 1) Qui appelle ? (JWT de l'utilisateur)
    const auth = req.headers.get("Authorization") ?? "";
    const asUser = createClient(url, anon, { global: { headers: { Authorization: auth } }, auth: { persistSession: false } });
    const { data: u, error: ue } = await asUser.auth.getUser();
    if (ue || !u?.user) return json({ error: "Connexion requise" }, 401);

    const { payment_id } = await req.json().catch(() => ({}));
    if (!payment_id || typeof payment_id !== "string") return json({ error: "payment_id manquant" }, 400);

    // 2) Le paiement appartient-il bien à l'appelant ? (lecture avec la clé serveur, contrôle explicite)
    const db = createClient(url, svc, { auth: { persistSession: false } });
    const { data: pay, error: pe } = await db.from("payments").select("id,amount,status,provider,provider_txn,checkout_url,orders(buyer_id,reseller_id,kind)").eq("id", payment_id).maybeSingle();
    if (pe || !pay) return json({ error: "Paiement introuvable" }, 404);
    const o = Array.isArray(pay.orders) ? pay.orders[0] : pay.orders;
    if (!o || (o.buyer_id !== u.user.id && o.reseller_id !== u.user.id)) return json({ error: "Non autorisé" }, 403);
    if (pay.status !== "pending") return json({ error: "Ce paiement n'est plus en attente" }, 409);
    if (!["orange_money", "moov_money"].includes(pay.provider)) return json({ error: "Moyen de paiement non pris en charge en ligne" }, 400);
    if (pay.checkout_url) return json({ payment_url: pay.checkout_url, reused: true });      // pas de seconde transaction pour le même paiement
    if (!Number.isInteger(pay.amount) || pay.amount < 100 || pay.amount % 5 !== 0) return json({ error: "Montant non accepté par CinetPay (minimum 100 FCFA, multiple de 5)." }, 400);

    const { data: prof } = await db.from("profiles").select("full_name").eq("id", u.user.id).maybeSingle();
    const parts = clean(prof?.full_name ?? "", 60).split(" ");
    const txn = txnFromPayment(pay.id);

    // 3) Création de la transaction chez CinetPay
    const r = await fetch(`${CINETPAY_BASE}/payment`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        apikey, site_id: siteId, transaction_id: txn, amount: pay.amount, currency: "XOF", channels: "MOBILE_MONEY", lang: "fr",
        description: o.kind === "activation" ? "Activation compte revendeur KANIS" : "Formation KANIS VPN ACADEMY",
        notify_url: notify, return_url: ret, metadata: pay.id,
        customer_id: u.user.id.slice(0, 20), customer_name: parts[0] || "Client", customer_surname: parts.slice(1).join(" ") || "KANIS",
      }),
    });
    const body = await r.json().catch(() => ({}));
    const link = body?.data?.payment_url;
    if (!r.ok || String(body?.code) !== "201" || !link) {
      console.error("cinetpay init refusé", { http: r.status, code: body?.code, message: body?.message });   // pas de donnée personnelle dans les journaux
      return json({ error: "Le prestataire de paiement a refusé la demande (" + (body?.message || r.status) + ")." }, 502);
    }
    const { error: se } = await db.from("payments").update({ provider_txn: txn, checkout_url: link }).eq("id", pay.id).eq("status", "pending");
    if (se) return json({ error: "Enregistrement impossible" }, 500);
    return json({ payment_url: link });
  } catch (e) {
    console.error("create-payment", (e as Error).message);
    return json({ error: "Erreur serveur" }, 500);
  }
});
