// Edge Function : notification de paiement CinetPay (notify_url). Déploiement : supabase functions deploy payment-webhook --no-verify-jwt
// Sécurité, dans cet ordre :
//   1. x-token (HMAC-SHA256 avec CINETPAY_SECRET_KEY) comparé en temps constant ;
//   2. cpm_site_id = CINETPAY_SITE_ID ;
//   3. contrôle serveur à serveur auprès de CinetPay (/payment/check) : statut, montant et devise ;
//   4. le montant payé doit être égal au montant enregistré dans la base ;
//   5. confirm_payment est idempotent (un paiement déjà traité n'est jamais rejoué) ; journal dans payment_events.
// Secrets : CINETPAY_API_KEY, CINETPAY_SITE_ID, CINETPAY_SECRET_KEY. Aucun numéro de téléphone n'est journalisé.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";
import { CINETPAY_BASE, HMAC_FIELDS, hmacInput, hmacSha256Hex, safeEqual } from "../_shared/cinetpay.ts";

const text = (s: string, status = 200) => new Response(s, { status });

Deno.serve(async (req) => {
  if (req.method === "GET" || req.method === "HEAD") return text("ok");           // CinetPay vérifie que l'URL répond
  if (req.method !== "POST") return text("méthode non autorisée", 405);
  try {
    const apikey = Deno.env.get("CINETPAY_API_KEY"), siteId = Deno.env.get("CINETPAY_SITE_ID"), secret = Deno.env.get("CINETPAY_SECRET_KEY");
    if (!apikey || !siteId || !secret) { console.error("webhook : secrets CinetPay manquants"); return text("non configuré", 503); }

    const ct = req.headers.get("content-type") ?? "";
    const f: Record<string, string> = {};
    if (ct.includes("application/json")) { const j = await req.json(); for (const k of Object.keys(j)) f[k] = String(j[k] ?? ""); }
    else { const fd = await req.formData(); for (const [k, v] of fd.entries()) f[k] = String(v); }

    // 1) signature
    const token = req.headers.get("x-token") ?? "";
    const expected = await hmacSha256Hex(secret, hmacInput(f));
    if (!token || !safeEqual(token.toLowerCase(), expected)) { console.warn("webhook : x-token invalide"); return text("signature invalide", 401); }
    // 2) site
    if (f.cpm_site_id !== siteId) return text("site inconnu", 401);
    const txn = f.cpm_trans_id;
    if (!txn) return text("cpm_trans_id manquant", 400);

    const db = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
    const { data: pay } = await db.from("payments").select("id,amount,status").eq("provider_txn", txn).maybeSingle();
    if (!pay) { console.warn("webhook : transaction inconnue"); return text("transaction inconnue", 404); }

    // 3) vérification serveur à serveur (on ne croit jamais le seul contenu de la notification)
    const chk = await fetch(`${CINETPAY_BASE}/payment/check`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ apikey, site_id: siteId, transaction_id: txn }),
    });
    const cj = await chk.json().catch(() => ({}));
    const status = String(cj?.data?.status ?? "");
    const log = (event: string) => db.from("payment_events").insert({
      payment_id: pay.id, provider: "cinetpay", provider_txn: txn, event,
      amount: Number(cj?.data?.amount) || null, currency: cj?.data?.currency ?? null, method: cj?.data?.payment_method ?? null,
    }).then(() => {}, () => {});                                                   // doublon (23505) ignoré : journal idempotent

    if (String(cj?.code) === "00" && status === "ACCEPTED") {
      // 4) montant et devise
      if (Number(cj.data.amount) !== pay.amount || cj.data.currency !== "XOF") {
        console.error("webhook : montant ou devise différent", { attendu: pay.amount, recu: cj.data.amount, devise: cj.data.currency });
        await log("AMOUNT_MISMATCH");
        return text("montant différent", 400);
      }
      // 5) confirmation (idempotente)
      const { error } = await db.rpc("confirm_payment", { p_payment: pay.id, p_reference: "CINETPAY:" + txn });
      if (error && !/déjà traité/i.test(error.message)) { console.error("confirm_payment", error.message); return text("erreur de confirmation", 500); }
      await log("ACCEPTED");
      return text("ok");
    }
    if (status === "REFUSED") {
      const { error } = await db.rpc("fail_payment", { p_payment: pay.id, p_reason: String(cj?.message ?? "REFUSED") });
      if (error) { console.error("fail_payment", error.message); return text("erreur", 500); }
      await log("REFUSED");
      return text("ok");
    }
    return text("en attente");                                                      // WAITING_CUSTOMER_* : on attend la prochaine notification
  } catch (e) {
    console.error("payment-webhook", (e as Error).message);
    return text("erreur serveur", 500);
  }
});
void HMAC_FIELDS;
