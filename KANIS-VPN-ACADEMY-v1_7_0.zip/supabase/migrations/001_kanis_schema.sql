-- KANIS VPN ACADEMY — schéma Supabase (à exécuter dans SQL Editor, une seule fois)
create extension if not exists pgcrypto;

-- ===== Paramètres =====
create table public.settings(key text primary key, value text not null);
insert into public.settings values ('reseller_activation_price','3000'),('reseller_share_percent','90'),('default_course_price','2500');

-- ===== Profils =====
create table public.profiles(
  id uuid primary key references auth.users on delete cascade,
  email text, full_name text, phone text,
  role text not null default 'buyer' check (role in ('buyer','reseller','admin')),
  reseller_status text not null default 'none' check (reseller_status in ('none','pending','active','suspended')),
  balance int not null default 0,
  created_at timestamptz default now());

create or replace function public.is_admin() returns boolean language sql stable security definer set search_path=public as
$$ select exists(select 1 from profiles where id=auth.uid() and role='admin') $$;

-- Le rôle n'est JAMAIS lu depuis les métadonnées envoyées par le client.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin
  insert into profiles(id,email,full_name,phone,role,reseller_status)
  values(new.id,new.email,left(new.raw_user_meta_data->>'full_name',80),left(new.raw_user_meta_data->>'phone',30),
    case when new.raw_user_meta_data->>'want_reseller'='true' then 'reseller' else 'buyer' end,
    case when new.raw_user_meta_data->>'want_reseller'='true' then 'pending' else 'none' end);
  return new; end $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function handle_new_user();

-- ===== Catalogue =====
create table public.courses(id uuid primary key default gen_random_uuid(), slug text unique not null, title text not null,
  description text, price int not null default 2500 check(price>=0), cover_url text, active boolean default true, created_at timestamptz default now());
create table public.chapters(id uuid primary key default gen_random_uuid(), course_id uuid references courses on delete cascade, title text not null, position int default 0);
create table public.videos(id uuid primary key default gen_random_uuid(), course_id uuid references courses on delete cascade,
  chapter_id uuid references chapters on delete set null, title text not null, url text not null, position int default 0);
insert into courses(slug,title,description,price) values
 ('dark-tunnel','DARK TUNNEL','Formation DARK TUNNEL',2500),('bkcbebe-tunnel','BKCBEBE TUNNEL','Formation BKCBEBE TUNNEL',2500);

-- ===== Promotions (système UNIQUE, y compris activation revendeur) =====
create table public.promotions(id uuid primary key default gen_random_uuid(), code text unique not null,
  kind text not null check(kind in ('percent','fixed')), value int not null check(value>0),
  starts_at timestamptz, ends_at timestamptz, max_uses int, uses int not null default 0,
  course_ids uuid[] not null default '{}', applies_to_activation boolean not null default false, active boolean not null default true);

-- ===== Commandes, paiements, commissions, codes =====
create table public.orders(id uuid primary key default gen_random_uuid(), buyer_id uuid references profiles, reseller_id uuid references profiles,
  course_id uuid references courses, kind text not null default 'course' check(kind in ('course','activation')),
  client_name text, client_phone text, amount int not null, promo_code text,
  status text not null default 'pending' check(status in ('pending','confirmed','refused','refunded')), created_at timestamptz default now());
create table public.payments(id uuid primary key default gen_random_uuid(), order_id uuid references orders on delete cascade,
  provider text not null check(provider in ('orange_money','wave','manual')), reference text, amount int not null,
  status text not null default 'pending' check(status in ('pending','confirmed','refused','refunded')),
  created_at timestamptz default now(), confirmed_at timestamptz, confirmed_by uuid);
create table public.commissions(id uuid primary key default gen_random_uuid(), reseller_id uuid references profiles, order_id uuid unique references orders,
  reseller_amount int not null, academy_amount int not null, created_at timestamptz default now());
create table public.access_codes(id uuid primary key default gen_random_uuid(), code_hash text unique not null, hint text,
  course_id uuid not null references courses, order_id uuid not null unique references orders, created_by uuid,
  status text not null default 'unused' check(status in ('unused','used','revoked')), used_by uuid, used_at timestamptz, created_at timestamptz default now());
create table public.enrollments(user_id uuid references profiles on delete cascade, course_id uuid references courses, order_id uuid references orders,
  primary key(user_id,course_id));
create table public.notifications(id uuid primary key default gen_random_uuid(), user_id uuid references profiles, title text, body text, created_at timestamptz default now());

-- ===== RLS =====
alter table settings enable row level security; alter table profiles enable row level security; alter table courses enable row level security;
alter table chapters enable row level security; alter table videos enable row level security; alter table promotions enable row level security;
alter table orders enable row level security; alter table payments enable row level security; alter table commissions enable row level security;
alter table access_codes enable row level security; alter table enrollments enable row level security; alter table notifications enable row level security;

create policy s_read on settings for select using (key in ('reseller_activation_price','default_course_price') or is_admin());
create policy s_admin on settings for all using (is_admin()) with check (is_admin());
create policy p_self on profiles for select using (id=auth.uid() or is_admin());
create policy p_upd on profiles for update using (id=auth.uid()) with check (id=auth.uid());
revoke update on profiles from authenticated, anon;
grant update(full_name,phone) on profiles to authenticated;      -- rôle, statut et solde: modifiables uniquement par fonctions serveur / admin RPC
create policy c_read on courses for select using (active or is_admin());
create policy c_admin on courses for all using (is_admin()) with check (is_admin());
create policy ch_read on chapters for select using (true);
create policy ch_admin on chapters for all using (is_admin()) with check (is_admin());
create policy v_admin on videos for all using (is_admin()) with check (is_admin());   -- les vidéos ne sont lisibles que via get_course_videos()
create policy pr_admin on promotions for all using (is_admin()) with check (is_admin());
create policy o_read on orders for select using (buyer_id=auth.uid() or reseller_id=auth.uid() or is_admin());
create policy pay_read on payments for select using (is_admin() or exists(select 1 from orders o where o.id=order_id and (o.buyer_id=auth.uid() or o.reseller_id=auth.uid())));
create policy cm_read on commissions for select using (reseller_id=auth.uid() or is_admin());
create policy ac_read on access_codes for select using (created_by=auth.uid() or is_admin());
create policy en_read on enrollments for select using (user_id=auth.uid() or is_admin());
create policy n_read on notifications for select using (user_id=auth.uid() or user_id is null or is_admin());
create policy n_admin on notifications for all using (is_admin()) with check (is_admin());
-- Aucune politique d'écriture sur orders/payments/commissions/access_codes/enrollments : tout passe par les fonctions ci-dessous.

-- ===== Prix (toujours calculé côté serveur) =====
create or replace function public.price_for(p_course uuid, p_promo text, p_activation boolean default false) returns int
language plpgsql stable security definer set search_path=public as $$
declare base int; pr promotions; res int;
begin
  if p_activation then select value::int into base from settings where key='reseller_activation_price';
  else select price into base from courses where id=p_course and active; end if;
  if base is null then raise exception 'Formation introuvable'; end if;
  if p_promo is null or p_promo='' then return base; end if;
  select * into pr from promotions where upper(code)=upper(p_promo) and active
     and (starts_at is null or starts_at<=now()) and (ends_at is null or ends_at>=now())
     and (max_uses is null or uses<max_uses)
     and ((p_activation and applies_to_activation) or (not p_activation and (course_ids='{}' or p_course=any(course_ids))));
  if not found then return base; end if;
  res := case when pr.kind='percent' then base - base*least(pr.value,100)/100 else greatest(base-pr.value,0) end;
  return res; end $$;

-- Prix d'activation affiché pendant l'inscription (promo automatique : la plus avantageuse en cours, sans code)
create or replace function public.activation_quote() returns json language plpgsql stable security definer set search_path=public as $$
declare base int; best int; begin
  select value::int into base from settings where key='reseller_activation_price';
  select min(case when kind='percent' then base-base*least(value,100)/100 else greatest(base-value,0) end) into best from promotions
   where active and applies_to_activation and (starts_at is null or starts_at<=now()) and (ends_at is null or ends_at>=now()) and (max_uses is null or uses<max_uses);
  return json_build_object('base',base,'final',coalesce(best,base)); end $$;

-- ===== Commandes =====
create or replace function public.create_order(p_course uuid, p_promo text default null, p_provider text default 'manual', p_client_name text default null, p_client_phone text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare oid uuid; amt int; me profiles; rid uuid; begin
  select * into me from profiles where id=auth.uid(); if not found then raise exception 'Connexion requise'; end if;
  if p_provider not in ('orange_money','wave','manual') then raise exception 'Fournisseur invalide'; end if;
  amt := price_for(p_course,p_promo,false);
  if me.role='reseller' and me.reseller_status='active' and p_client_name is not null then rid:=me.id; end if;
  insert into orders(buyer_id,reseller_id,course_id,client_name,client_phone,amount,promo_code) values(case when rid is null then me.id end,rid,p_course,p_client_name,p_client_phone,amt,nullif(p_promo,'')) returning id into oid;
  insert into payments(order_id,provider,amount) values(oid,p_provider,amt);
  return oid; end $$;

create or replace function public.request_activation(p_promo text default null, p_provider text default 'manual') returns uuid
language plpgsql security definer set search_path=public as $$
declare oid uuid; amt int; begin
  if not exists(select 1 from profiles where id=auth.uid() and role='reseller' and reseller_status='pending') then raise exception 'Non autorisé'; end if;
  amt := price_for(null,p_promo,true);
  insert into orders(buyer_id,kind,amount,promo_code) values(auth.uid(),'activation',amt,nullif(p_promo,'')) returning id into oid;
  insert into payments(order_id,provider,amount) values(oid,p_provider,amt); return oid; end $$;

-- ===== Confirmation (admin ou webhook via service_role) =====
create or replace function public.confirm_payment(p_payment uuid, p_reference text default null) returns void
language plpgsql security definer set search_path=public as $$
declare pay payments; o orders; share int; rc int; begin
  if not (is_admin() or auth.role()='service_role') then raise exception 'Réservé à l''administrateur'; end if;
  select * into pay from payments where id=p_payment for update;
  if pay.status<>'pending' then raise exception 'Paiement déjà traité'; end if;
  select * into o from orders where id=pay.order_id for update;
  update payments set status='confirmed', reference=coalesce(p_reference,reference), confirmed_at=now(), confirmed_by=auth.uid() where id=pay.id;
  update orders set status='confirmed' where id=o.id;
  if o.promo_code is not null then update promotions set uses=uses+1 where upper(code)=upper(o.promo_code); end if;
  if o.kind='activation' then update profiles set reseller_status='active' where id=o.buyer_id;
  elsif o.reseller_id is not null then
    select value::int into share from settings where key='reseller_share_percent';
    rc := o.amount*share/100;
    insert into commissions(reseller_id,order_id,reseller_amount,academy_amount) values(o.reseller_id,o.id,rc,o.amount-rc);
    update profiles set balance=balance+rc where id=o.reseller_id;
  else insert into enrollments(user_id,course_id,order_id) values(o.buyer_id,o.course_id,o.id) on conflict do nothing; end if;
  insert into notifications(user_id,title,body) values(coalesce(o.buyer_id,o.reseller_id),'Paiement confirmé','Votre paiement de '||o.amount||' FCFA est confirmé.');
end $$;

create or replace function public.refuse_payment(p_payment uuid, p_refund boolean default false) returns void
language plpgsql security definer set search_path=public as $$
declare pay payments; o orders; c commissions; begin
  if not is_admin() then raise exception 'Réservé à l''administrateur'; end if;
  select * into pay from payments where id=p_payment for update; select * into o from orders where id=pay.order_id;
  if p_refund and pay.status='confirmed' then
    update payments set status='refunded' where id=pay.id; update orders set status='refunded' where id=o.id;
    select * into c from commissions where order_id=o.id;
    if found then update profiles set balance=balance-c.reseller_amount where id=c.reseller_id; delete from commissions where id=c.id; end if;
    update access_codes set status='revoked' where order_id=o.id;
    delete from enrollments where order_id=o.id;
  elsif pay.status='pending' then update payments set status='refused' where id=pay.id; update orders set status='refused' where id=o.id; end if;
end $$;

-- ===== Codes d'accès : générés après paiement confirmé, valeur en clair retournée UNE seule fois =====
create or replace function public.generate_code(p_order uuid) returns text language plpgsql security definer set search_path=public as $$
declare o orders; plain text; begin
  select * into o from orders where id=p_order;
  if not found or o.kind<>'course' or o.status<>'confirmed' then raise exception 'Commande non confirmée'; end if;
  if not (is_admin() or o.reseller_id=auth.uid()) then raise exception 'Non autorisé'; end if;
  if exists(select 1 from access_codes where order_id=p_order) then raise exception 'Code déjà généré pour cette commande'; end if;
  if o.reseller_id is not null and not exists(select 1 from profiles where id=o.reseller_id and reseller_status='active') then raise exception 'Revendeur suspendu'; end if;
  plain := (select upper(substr(slug,1,2)) from courses where id=o.course_id)||'-'||upper(encode(gen_random_bytes(5),'hex'));
  insert into access_codes(code_hash,hint,course_id,order_id,created_by) values(encode(digest(plain,'sha256'),'hex'),right(plain,3),o.course_id,p_order,auth.uid());
  return plain; end $$;

create or replace function public.redeem_code(p_code text) returns text language plpgsql security definer set search_path=public as $$
declare ac access_codes; slug text; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  select * into ac from access_codes where code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex') and status='unused' for update;
  if not found then raise exception 'Code invalide ou déjà utilisé'; end if;
  update access_codes set status='used', used_by=auth.uid(), used_at=now() where id=ac.id;
  insert into enrollments(user_id,course_id,order_id) values(auth.uid(),ac.course_id,ac.order_id) on conflict do nothing;
  select courses.slug into slug from courses where id=ac.course_id; return slug; end $$;

create or replace function public.my_access() returns text[] language sql stable security definer set search_path=public as
$$ select coalesce(array_agg(c.slug),'{}') from courses c where is_admin() or exists(select 1 from enrollments e where e.course_id=c.id and e.user_id=auth.uid()) $$;

create or replace function public.get_course_videos(p_slug text) returns table(title text,url text,chapter text,pos int)
language sql stable security definer set search_path=public as $$
  select v.title,v.url,ch.title,v.position from videos v join courses c on c.id=v.course_id left join chapters ch on ch.id=v.chapter_id
  where c.slug=p_slug and (is_admin() or exists(select 1 from enrollments e where e.course_id=c.id and e.user_id=auth.uid())) order by v.position $$;

-- ===== Admin =====
create or replace function public.admin_stats() returns json language plpgsql stable security definer set search_path=public as $$
begin if not is_admin() then raise exception 'Non autorisé'; end if;
return json_build_object(
 'buyers',(select count(*) from profiles where role='buyer'),'resellers',(select count(*) from profiles where role='reseller'),
 'sales',(select count(*) from orders where status='confirmed' and kind='course'),
 'revenue',(select coalesce(sum(amount),0) from orders where status='confirmed'),
 'commissions',(select coalesce(sum(reseller_amount),0) from commissions),
 'academy',(select coalesce(sum(academy_amount),0) from commissions)+(select coalesce(sum(amount),0) from orders where status='confirmed' and reseller_id is null)); end $$;

create or replace function public.admin_set_reseller(p_user uuid, p_status text) returns void language plpgsql security definer set search_path=public as $$
begin if not is_admin() then raise exception 'Non autorisé'; end if;
 if p_status not in ('active','suspended') then raise exception 'Statut invalide'; end if;
 update profiles set reseller_status=p_status where id=p_user and role='reseller'; end $$;
-- Premier administrateur : à faire UNE fois depuis le SQL Editor (jamais depuis l'app) :
--   update public.profiles set role='admin' where email='TON_EMAIL';

revoke execute on function public.confirm_payment(uuid,text) from anon;
