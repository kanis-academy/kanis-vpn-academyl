-- KANIS VPN ACADEMY — migration 004 (à exécuter APRÈS 001, 002 et 003, dans le SQL Editor)
-- Réexécutable : create or replace / if not exists / drop ... if exists. Aucune donnée n'est supprimée.
-- Contenu : opérateurs Burkina Faso (Orange Money BF, Moov Money BF via CinetPay), journal des événements de paiement,
-- retraits revendeur (solde bloqué dès la demande), vue admin des revendeurs, validation des réglages, droits d'exécution.

-- ===== 1. Opérateurs de paiement =====
-- 'wave' reste accepté UNIQUEMENT pour l'historique : sa compatibilité Burkina Faso n'est pas confirmée par la documentation CinetPay.
alter table public.payments drop constraint if exists payments_provider_check;
alter table public.payments add constraint payments_provider_check
  check (provider in ('orange_money','moov_money','wave','cinetpay','manual'));

alter table public.payments add column if not exists provider_txn text;      -- identifiant de transaction envoyé au prestataire
alter table public.payments add column if not exists checkout_url text;      -- lien de paiement hébergé
alter table public.payments add column if not exists failure_reason text;
create unique index if not exists payments_provider_txn_uq on public.payments(provider_txn) where provider_txn is not null;

-- create_order accepte maintenant les opérateurs burkinabè
create or replace function public.create_order(p_course uuid, p_promo text default null, p_provider text default 'manual', p_client_name text default null, p_client_phone text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare oid uuid; amt int; me profiles; rid uuid; begin
  select * into me from profiles where id=auth.uid(); if not found then raise exception 'Connexion requise'; end if;
  if p_provider not in ('orange_money','moov_money','manual') then raise exception 'Fournisseur invalide'; end if;
  if me.role='reseller' then
    if me.reseller_status<>'active' then raise exception 'Compte revendeur inactif : active-le pour vendre'; end if;
    if p_client_name is not null then rid:=me.id; end if;
  end if;
  amt := price_for(p_course,p_promo,false);
  insert into orders(buyer_id,reseller_id,course_id,client_name,client_phone,amount,promo_code)
  values(case when rid is null then me.id end,rid,p_course,p_client_name,p_client_phone,amt,nullif(p_promo,'')) returning id into oid;
  insert into payments(order_id,provider,amount) values(oid,p_provider,amt);
  return oid; end $$;

-- request_activation : Orange Money BF ou Moov Money BF (le reste de la logique de 003 est conservé)
create or replace function public.request_activation(p_promo text default null, p_provider text default 'orange_money') returns uuid
language plpgsql security definer set search_path=public as $$
declare oid uuid; base int; amt int; used text; best_code text; best_amt int; code_amt int; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if p_provider not in ('orange_money','moov_money') then raise exception 'Choisis Orange Money ou Moov Money'; end if;
  perform 1 from profiles where id=auth.uid() for update;
  if not exists(select 1 from profiles where id=auth.uid() and role='reseller' and reseller_status='pending') then
    raise exception 'Ce compte n''a pas besoin d''être activé'; end if;
  select id into oid from orders where buyer_id=auth.uid() and kind='activation' and status='pending' limit 1;
  if oid is not null then
    update payments set provider=p_provider where order_id=oid and status='pending';
    return oid; end if;
  select value::int into base from settings where key='reseller_activation_price';
  select code, case when kind='percent' then base-base*least(value,100)/100 else greatest(base-value,0) end
    into best_code, best_amt from promotions
   where active and applies_to_activation and (starts_at is null or starts_at<=now()) and (ends_at is null or ends_at>=now()) and (max_uses is null or uses<max_uses)
   order by 2 asc limit 1;
  amt := base; used := null;
  if best_amt is not null and best_amt<amt then amt:=best_amt; used:=best_code; end if;
  if nullif(p_promo,'') is not null then
    code_amt := price_for(null,p_promo,true);
    if code_amt<amt then amt:=code_amt; used:=upper(p_promo); end if; end if;
  insert into orders(buyer_id,kind,amount,promo_code) values(auth.uid(),'activation',amt,used) returning id into oid;
  insert into payments(order_id,provider,amount) values(oid,p_provider,amt);
  return oid; end $$;

-- ===== 2. Journal des événements de paiement (audit + idempotence, sans donnée personnelle) =====
create table if not exists public.payment_events(
  id uuid primary key default gen_random_uuid(),
  payment_id uuid references public.payments on delete set null,
  provider text not null, provider_txn text not null, event text not null,
  amount int, currency text, method text,
  created_at timestamptz not null default now(),
  unique(provider, provider_txn, event));
alter table public.payment_events enable row level security;
drop policy if exists pe_admin on public.payment_events;
create policy pe_admin on public.payment_events for select using (is_admin());
-- aucune politique d'écriture : seul le serveur (service_role, Edge Function) écrit dans ce journal.

-- ===== 3. Paiement échoué / annulé (appelé par le webhook, ou par l'administrateur) =====
create or replace function public.fail_payment(p_payment uuid, p_reason text default null) returns void
language plpgsql security definer set search_path=public as $$
declare pay payments; begin
  if not (is_admin() or coalesce(auth.jwt()->>'role','')='service_role') then raise exception 'Réservé à l''administrateur'; end if;
  select * into pay from payments where id=p_payment for update;
  if not found then raise exception 'Paiement introuvable'; end if;
  if pay.status<>'pending' then return; end if;                -- idempotent : un paiement déjà traité n'est jamais modifié
  update payments set status='refused', failure_reason=left(coalesce(p_reason,'échec'),200) where id=pay.id;
  update orders set status='refused' where id=pay.order_id and status='pending';
  perform notify((select coalesce(buyer_id,reseller_id) from orders where id=pay.order_id),'Paiement non abouti','Ton paiement n''a pas été validé. Tu peux réessayer.');
end $$;
revoke execute on function public.fail_payment(uuid,text) from public, anon;
grant execute on function public.fail_payment(uuid,text) to authenticated, service_role;

-- ===== 4. Confirmation de paiement (remplace 003) =====
-- Admin : référence obligatoire. Webhook : appelé avec la clé service_role APRÈS vérification HMAC + contrôle serveur à serveur.
create or replace function public.confirm_payment(p_payment uuid, p_reference text default null) returns void
language plpgsql security definer set search_path=public as $$
declare pay payments; o orders; share int; rc int; n int; svc boolean := coalesce(auth.jwt()->>'role','')='service_role'; begin
  if not (is_admin() or svc) then raise exception 'Réservé à l''administrateur'; end if;
  if not svc and nullif(btrim(coalesce(p_reference,'')),'') is null then raise exception 'Référence de transaction requise'; end if;
  select * into pay from payments where id=p_payment for update;
  if not found then raise exception 'Paiement introuvable'; end if;
  if pay.status<>'pending' then raise exception 'Paiement déjà traité'; end if;
  select * into o from orders where id=pay.order_id for update;
  if o.kind='activation' then
    update profiles set reseller_status='active' where id=o.buyer_id and role='reseller' and reseller_status='pending';
    get diagnostics n = row_count;
    if n=0 then raise exception 'Ce compte n''est pas en attente d''activation (déjà actif ou suspendu)'; end if;
  elsif o.reseller_id is not null and not exists(select 1 from profiles where id=o.reseller_id and reseller_status='active') then
    raise exception 'Revendeur inactif : aucune commission possible (refuse le paiement ou réactive le revendeur)';
  end if;
  update payments set status='confirmed', reference=coalesce(nullif(btrim(p_reference),''),reference), confirmed_at=now(), confirmed_by=auth.uid() where id=pay.id;
  update orders set status='confirmed' where id=o.id;
  if o.promo_code is not null then update promotions set uses=uses+1 where upper(code)=upper(o.promo_code); end if;
  if o.kind='activation' then
    perform notify(o.buyer_id,'Compte revendeur activé','Ton espace revendeur est prêt.');
    perform notify(a.id,'Revendeur activé','Un revendeur vient de payer son activation.') from profiles a where a.role='admin';
  elsif o.reseller_id is not null then
    select value::int into share from settings where key='reseller_share_percent';
    share := coalesce(share,90);
    rc := o.amount*share/100;                                  -- 90 % revendeur (réglage), le reste pour la plateforme
    insert into commissions(reseller_id,order_id,reseller_amount,academy_amount) values(o.reseller_id,o.id,rc,o.amount-rc);   -- order_id unique : pas de double commission
    update profiles set balance=balance+rc where id=o.reseller_id;
    perform notify(o.reseller_id,'Paiement confirmé · nouvelle commission','Commission de '||rc||' FCFA créditée. Tu peux générer le code du client.');
  else
    insert into enrollments(user_id,course_id,order_id) values(o.buyer_id,o.course_id,o.id) on conflict do nothing;
    perform notify(o.buyer_id,'Paiement confirmé',o.amount||' FCFA reçus.');
  end if;
end $$;
revoke execute on function public.confirm_payment(uuid,text) from public, anon;
grant execute on function public.confirm_payment(uuid,text) to authenticated, service_role;

-- ===== 5. Retraits revendeur =====
insert into public.settings(key,value) values('min_withdrawal','1000') on conflict (key) do nothing;
drop policy if exists s_read on public.settings;
create policy s_read on public.settings for select using (key in ('reseller_activation_price','default_course_price','min_withdrawal') or is_admin());

create or replace function public.trg_settings_validate() returns trigger language plpgsql as $$
begin
  if new.key in ('reseller_activation_price','reseller_share_percent','default_course_price','min_withdrawal') and new.value !~ '^[0-9]+$' then
    raise exception 'Valeur entière positive requise pour %', new.key; end if;
  if new.key='reseller_share_percent' and new.value::int>100 then raise exception 'Le pourcentage doit être compris entre 0 et 100'; end if;
  return new; end $$;
drop trigger if exists settings_validate on public.settings;
create trigger settings_validate before insert or update on public.settings for each row execute function public.trg_settings_validate();

create table if not exists public.withdrawals(
  id uuid primary key default gen_random_uuid(),
  reseller_id uuid not null references public.profiles on delete restrict,
  amount int not null check (amount>0),
  method text not null check (method in ('orange_money','moov_money')),
  phone text not null,
  status text not null default 'pending' check (status in ('pending','accepted','refused')),
  admin_note text, processed_by uuid, processed_at timestamptz,
  created_at timestamptz not null default now());
create unique index if not exists one_pending_withdrawal on public.withdrawals(reseller_id) where status='pending';   -- pas de double demande
create index if not exists withdrawals_reseller_idx on public.withdrawals(reseller_id, created_at desc);
alter table public.withdrawals enable row level security;
drop policy if exists w_read on public.withdrawals;
create policy w_read on public.withdrawals for select using (reseller_id=auth.uid() or is_admin());
-- aucune politique d'écriture : tout passe par request_withdrawal / admin_process_withdrawal.

-- Le montant est débité du solde DÈS la demande (impossible de dépenser deux fois) ; un refus le recrédite.
create or replace function public.request_withdrawal(p_amount int, p_method text, p_phone text) returns uuid
language plpgsql security definer set search_path=public as $$
declare me profiles; minw int; wid uuid; ph text; a record; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  select * into me from profiles where id=auth.uid() for update;                 -- verrou : sérialise les doubles clics
  if not found or me.role<>'reseller' or me.reseller_status<>'active' then raise exception 'Réservé aux revendeurs actifs'; end if;
  if p_method not in ('orange_money','moov_money') then raise exception 'Choisis Orange Money ou Moov Money'; end if;
  ph := regexp_replace(coalesce(p_phone,''),'[ .-]','','g');
  if ph !~ '^(\+?226)?[0-9]{8}$' then raise exception 'Numéro invalide : 8 chiffres (Burkina Faso)'; end if;
  select value::int into minw from settings where key='min_withdrawal'; minw := coalesce(minw,1000);
  if p_amount is null or p_amount<minw then raise exception 'Montant minimum de retrait : % FCFA', minw; end if;
  if p_amount>me.balance then raise exception 'Solde insuffisant'; end if;
  if exists(select 1 from withdrawals where reseller_id=me.id and status='pending') then raise exception 'Une demande de retrait est déjà en attente'; end if;
  update profiles set balance=balance-p_amount where id=me.id;
  insert into withdrawals(reseller_id,amount,method,phone) values(me.id,p_amount,p_method,ph) returning id into wid;
  for a in select id from profiles where role='admin' loop
    perform notify(a.id,'Demande de retrait',coalesce(me.full_name,me.email,'Un revendeur')||' demande '||p_amount||' FCFA'); end loop;
  perform notify(me.id,'Demande de retrait enregistrée',p_amount||' FCFA en attente de validation.');
  return wid; end $$;

create or replace function public.admin_process_withdrawal(p_id uuid, p_accept boolean, p_note text default null) returns void
language plpgsql security definer set search_path=public as $$
declare w withdrawals; begin
  if not is_admin() then raise exception 'Non autorisé'; end if;
  select * into w from withdrawals where id=p_id for update;
  if not found then raise exception 'Demande introuvable'; end if;
  if w.status<>'pending' then raise exception 'Demande déjà traitée'; end if;
  if p_accept then
    update withdrawals set status='accepted', admin_note=left(p_note,300), processed_by=auth.uid(), processed_at=now() where id=w.id;
    perform notify(w.reseller_id,'Retrait accepté',w.amount||' FCFA seront envoyés sur ton compte '||case w.method when 'moov_money' then 'Moov Money' else 'Orange Money' end||'.');
  else
    update withdrawals set status='refused', admin_note=left(p_note,300), processed_by=auth.uid(), processed_at=now() where id=w.id;
    update profiles set balance=balance+w.amount where id=w.reseller_id;           -- recrédit
    perform notify(w.reseller_id,'Retrait refusé',w.amount||' FCFA ont été recrédités sur ton solde.'||coalesce(' Motif : '||nullif(p_note,''),''));
  end if; end $$;

-- ===== 6. Vue administrateur des revendeurs : actifs / inactifs, activation payée ou non =====
create or replace function public.admin_resellers()
returns table(user_id uuid, full_name text, email text, phone text, status text, activation_paid boolean, balance_fcfa int, sales_count bigint, created_at timestamptz)
language plpgsql stable security definer set search_path=public as $$
begin
  if not is_admin() then raise exception 'Non autorisé'; end if;
  return query
    select p.id, p.full_name, p.email, p.phone, p.reseller_status,
           exists(select 1 from orders o where o.buyer_id=p.id and o.kind='activation' and o.status='confirmed'),
           p.balance,
           (select count(*) from orders o2 where o2.reseller_id=p.id and o2.status='confirmed'),
           p.created_at
      from profiles p where p.role='reseller'
     order by (p.reseller_status='active'), p.created_at desc;      -- inactifs en premier
end $$;

-- ===== 7. Droits d'exécution : rien n'est appelable sans connexion, sauf le prix d'activation affiché à l'inscription =====
revoke execute on function public.price_for(uuid,text,boolean) from public, anon;
revoke execute on function public.create_order(uuid,text,text,text,text) from public, anon;
revoke execute on function public.request_activation(text,text) from public, anon;
revoke execute on function public.refuse_payment(uuid,boolean) from public, anon;
revoke execute on function public.generate_code(uuid) from public, anon;
revoke execute on function public.redeem_code(text) from public, anon;
revoke execute on function public.my_access() from public, anon;
revoke execute on function public.get_course_videos(text) from public, anon;
revoke execute on function public.admin_stats() from public, anon;
revoke execute on function public.admin_set_reseller(uuid,text) from public, anon;
revoke execute on function public.admin_set_role(uuid,text) from public, anon;
revoke execute on function public.request_withdrawal(int,text,text) from public, anon;
revoke execute on function public.admin_process_withdrawal(uuid,boolean,text) from public, anon;
revoke execute on function public.admin_resellers() from public, anon;
grant execute on function public.create_order(uuid,text,text,text,text) to authenticated;
grant execute on function public.request_activation(text,text) to authenticated;
grant execute on function public.refuse_payment(uuid,boolean) to authenticated;
grant execute on function public.generate_code(uuid) to authenticated;
grant execute on function public.redeem_code(text) to authenticated;
grant execute on function public.my_access() to authenticated;
grant execute on function public.get_course_videos(text) to authenticated;
grant execute on function public.admin_stats() to authenticated;
grant execute on function public.admin_set_reseller(uuid,text) to authenticated;
grant execute on function public.admin_set_role(uuid,text) to authenticated;
grant execute on function public.request_withdrawal(int,text,text) to authenticated;
grant execute on function public.admin_process_withdrawal(uuid,boolean,text) to authenticated;
grant execute on function public.admin_resellers() to authenticated;
grant execute on function public.activation_quote() to anon, authenticated;
