-- KANIS VPN ACADEMY — migration 003 (à exécuter APRÈS 001 et 002, dans le SQL Editor)
-- Inscription directe (sans confirmation e-mail), profils sans incohérence,
-- activation revendeur sans double paiement ni double activation.

-- ===== 1. Création du profil à l'inscription (robuste, jamais admin) =====
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path=public as $$
declare want boolean := coalesce(new.raw_user_meta_data->>'want_reseller','')='true';
begin
  insert into profiles(id,email,full_name,phone,role,reseller_status)
  values(new.id,new.email,
    left(btrim(coalesce(new.raw_user_meta_data->>'full_name','')),80),
    left(btrim(coalesce(new.raw_user_meta_data->>'phone','')),30),
    case when want then 'reseller' else 'buyer' end,      -- le rôle admin n'est JAMAIS attribué ici
    case when want then 'pending' else 'none' end)
  on conflict (id) do nothing;
  return new; end $$;

-- Répare un compte Auth sans profil (rôle toujours buyer/reseller, jamais admin)
create or replace function public.ensure_profile() returns void
language plpgsql security definer set search_path=public,auth as $$
declare u auth.users; want boolean; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if exists(select 1 from profiles where id=auth.uid()) then return; end if;
  select * into u from auth.users where id=auth.uid();
  if not found then raise exception 'Utilisateur introuvable'; end if;
  want := coalesce(u.raw_user_meta_data->>'want_reseller','')='true';
  insert into profiles(id,email,full_name,phone,role,reseller_status)
  values(u.id,u.email,left(btrim(coalesce(u.raw_user_meta_data->>'full_name','')),80),
    left(btrim(coalesce(u.raw_user_meta_data->>'phone','')),30),
    case when want then 'reseller' else 'buyer' end, case when want then 'pending' else 'none' end)
  on conflict (id) do nothing; end $$;
revoke execute on function public.ensure_profile() from public, anon;
grant execute on function public.ensure_profile() to authenticated;

-- Le prix d'activation (avec promotion automatique) est affiché avant l'inscription
grant execute on function public.activation_quote() to anon, authenticated;

-- ===== 2. Un seul paiement d'activation en attente / confirmé par compte =====
create unique index if not exists one_pending_activation   on public.orders(buyer_id) where kind='activation' and status='pending';
create unique index if not exists one_confirmed_activation on public.orders(buyer_id) where kind='activation' and status='confirmed';

-- ===== 3. Demande d'activation : idempotente, promotion appliquée côté serveur =====
create or replace function public.request_activation(p_promo text default null, p_provider text default 'manual') returns uuid
language plpgsql security definer set search_path=public as $$
declare oid uuid; base int; amt int; used text; best_code text; best_amt int; code_amt int; begin
  if auth.uid() is null then raise exception 'Connexion requise'; end if;
  if p_provider not in ('orange_money','wave') then raise exception 'Choisis Orange Money ou Wave'; end if;
  perform 1 from profiles where id=auth.uid() for update;            -- sérialise les doubles clics
  if not exists(select 1 from profiles where id=auth.uid() and role='reseller' and reseller_status='pending') then
    raise exception 'Ce compte n''a pas besoin d''être activé'; end if;
  select id into oid from orders where buyer_id=auth.uid() and kind='activation' and status='pending' limit 1;
  if oid is not null then
    update payments set provider=p_provider where order_id=oid and status='pending';
    return oid; end if;                                               -- déjà une demande en attente
  select value::int into base from settings where key='reseller_activation_price';
  select code, case when kind='percent' then base-base*least(value,100)/100 else greatest(base-value,0) end
    into best_code, best_amt from promotions
   where active and applies_to_activation and (starts_at is null or starts_at<=now()) and (ends_at is null or ends_at>=now()) and (max_uses is null or uses<max_uses)
   order by 2 asc limit 1;
  amt := base; used := null;
  if best_amt is not null and best_amt<amt then amt:=best_amt; used:=best_code; end if;   -- promotion automatique (même celle affichée à l'inscription)
  if nullif(p_promo,'') is not null then
    code_amt := price_for(null,p_promo,true);
    if code_amt<amt then amt:=code_amt; used:=upper(p_promo); end if; end if;
  insert into orders(buyer_id,kind,amount,promo_code) values(auth.uid(),'activation',amt,used) returning id into oid;
  insert into payments(order_id,provider,amount) values(oid,p_provider,amt);
  return oid; end $$;

-- ===== 4. Un revendeur inactif ne peut pas vendre =====
create or replace function public.create_order(p_course uuid, p_promo text default null, p_provider text default 'manual', p_client_name text default null, p_client_phone text default null)
returns uuid language plpgsql security definer set search_path=public as $$
declare oid uuid; amt int; me profiles; rid uuid; begin
  select * into me from profiles where id=auth.uid(); if not found then raise exception 'Connexion requise'; end if;
  if p_provider not in ('orange_money','wave','manual') then raise exception 'Fournisseur invalide'; end if;
  if me.role='reseller' then
    if me.reseller_status<>'active' then raise exception 'Compte revendeur inactif : active-le pour vendre'; end if;
    if p_client_name is not null then rid:=me.id; end if;
  end if;
  amt := price_for(p_course,p_promo,false);
  insert into orders(buyer_id,reseller_id,course_id,client_name,client_phone,amount,promo_code)
  values(case when rid is null then me.id end,rid,p_course,p_client_name,p_client_phone,amt,nullif(p_promo,'')) returning id into oid;
  insert into payments(order_id,provider,amount) values(oid,p_provider,amt);
  return oid; end $$;

-- ===== 5. Confirmation de paiement : pas de commission pour un revendeur inactif, pas de double activation =====
create or replace function public.confirm_payment(p_payment uuid, p_reference text default null) returns void
language plpgsql security definer set search_path=public as $$
declare pay payments; o orders; share int; rc int; n int; begin
  if not (is_admin() or auth.role()='service_role') then raise exception 'Réservé à l''administrateur'; end if;
  select * into pay from payments where id=p_payment for update;
  if not found then raise exception 'Paiement introuvable'; end if;
  if pay.status<>'pending' then raise exception 'Paiement déjà traité'; end if;
  select * into o from orders where id=pay.order_id for update;
  if o.kind='activation' then
    update profiles set reseller_status='active' where id=o.buyer_id and role='reseller' and reseller_status='pending';
    get diagnostics n = row_count;
    if n=0 then raise exception 'Ce compte n''est pas en attente d''activation (déjà actif ou suspendu)'; end if;
  elsif o.reseller_id is not null and not exists(select 1 from profiles where id=o.reseller_id and reseller_status='active') then
    raise exception 'Revendeur inactif : aucune commission possible (refuse le paiement ou réactive le revendeur)';
  end if;
  update payments set status='confirmed', reference=coalesce(p_reference,reference), confirmed_at=now(), confirmed_by=auth.uid() where id=pay.id;
  update orders set status='confirmed' where id=o.id;
  if o.promo_code is not null then update promotions set uses=uses+1 where upper(code)=upper(o.promo_code); end if;
  if o.kind='activation' then
    perform notify(o.buyer_id,'Compte revendeur activé','Ton espace revendeur est prêt.');
  elsif o.reseller_id is not null then
    select value::int into share from settings where key='reseller_share_percent';
    rc := o.amount*share/100;
    insert into commissions(reseller_id,order_id,reseller_amount,academy_amount) values(o.reseller_id,o.id,rc,o.amount-rc);
    update profiles set balance=balance+rc where id=o.reseller_id;
    perform notify(o.reseller_id,'Paiement confirmé · nouvelle commission','Commission de '||rc||' FCFA créditée. Tu peux générer le code du client.');
  else
    insert into enrollments(user_id,course_id,order_id) values(o.buyer_id,o.course_id,o.id) on conflict do nothing;
    perform notify(o.buyer_id,'Paiement confirmé',o.amount||' FCFA reçus.');
  end if;
end $$;
revoke execute on function public.confirm_payment(uuid,text) from public, anon;
grant execute on function public.confirm_payment(uuid,text) to authenticated, service_role;
