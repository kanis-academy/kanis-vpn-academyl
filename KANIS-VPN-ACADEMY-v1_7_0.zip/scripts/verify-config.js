// Vérifications statiques exécutées AVANT la compilation (npm run verify). Aucune requête réseau.
// 1) config.js : format attendu, URL https non locale, clé publique (jamais service_role / sb_secret_)
// 2) tous les fichiers de www/ : aucune clé secrète
// 3) index.html : ordre de chargement vendor/supabase.js -> config.js -> kanis-backend.js
// 4) www/js/vendor/supabase.js présent et valide (si --vendor)
const fs = require("fs"), path = require("path"), vm = require("vm");
const root = path.join(__dirname, "..");
const errs = [], ok = (m) => console.log("OK  " + m), ko = (m) => { errs.push(m); console.error("ERR " + m); };

const cfgSrc = fs.readFileSync(path.join(root, "www/js/config.js"), "utf8");
const sandbox = { window: {} }; vm.createContext(sandbox);
try { vm.runInContext(cfgSrc, sandbox); } catch (e) { ko("config.js ne s'exécute pas : " + e.message); }
const C = sandbox.window.KANIS_SUPABASE;
if (!C) ko("config.js doit définir window.KANIS_SUPABASE = { url, anonKey, redirectTo }");
else {
  if (!/^https:\/\/[a-z0-9-]+\.supabase\.co$/.test(C.url || "")) ko("url Supabase invalide : " + C.url); else ok("url Supabase : " + C.url);
  if (!/^(sb_publishable_[A-Za-z0-9_-]{20,}|eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+)$/.test(C.anonKey || "")) ko("clé publique absente ou au mauvais format");
  else ok("clé publique au format attendu (" + String(C.anonKey).slice(0, 16) + "…)");
  const m = (C.url || "").match(/^https:\/\/([a-z0-9]+)\.supabase\.co$/);
  const toml = fs.readFileSync(path.join(root, "supabase/config.toml"), "utf8");
  if (m && !toml.includes('project_id = "' + m[1] + '"')) ko("supabase/config.toml ne vise pas le même projet que config.js (" + m[1] + ")"); else ok("config.toml et config.js visent le même projet");
  if (/^eyJ/.test(C.anonKey || "")) { try { const role = JSON.parse(Buffer.from(C.anonKey.split(".")[1], "base64url").toString()).role; if (role !== "anon") ko("la clé JWT a le rôle « " + role + " » (attendu : anon)"); } catch (e) { ko("clé JWT illisible"); } }
}
function walk(d) { return fs.readdirSync(d, { withFileTypes: true }).flatMap((e) => e.isDirectory() ? walk(path.join(d, e.name)) : [path.join(d, e.name)]); }
const bad = walk(path.join(root, "www")).filter((f) => /\.(js|html|json)$/.test(f) && !f.includes("/vendor/")).filter((f) => /sb_secret_|service_role|SUPABASE_SERVICE/.test(fs.readFileSync(f, "utf8")) && !f.endsWith("kanis-backend.js") && !f.endsWith("config.js"));
// kanis-backend.js / config.js citent ces mots dans des messages et commentaires : contrôle dédié (valeur de clé uniquement)
const secretValue = walk(path.join(root, "www")).filter((f) => !f.includes("/vendor/") && /\.(js|html)$/.test(f)).filter((f) => /sb_secret_[A-Za-z0-9_-]{10,}/.test(fs.readFileSync(f, "utf8")));
if (bad.length || secretValue.length) ko("clé secrète trouvée dans : " + bad.concat(secretValue).join(", ")); else ok("aucune clé secrète dans www/");

const html = fs.readFileSync(path.join(root, "www/index.html"), "utf8");
const i1 = html.indexOf('src="js/vendor/supabase.js"'), i2 = html.indexOf('src="js/config.js"'), i3 = html.indexOf('src="js/kanis-backend.js"');
if (i1 < 0 || i2 < 0 || i3 < 0 || !(i1 < i2 && i2 < i3)) ko("ordre des scripts incorrect dans index.html (supabase.js, config.js, kanis-backend.js)"); else ok("ordre de chargement des scripts correct");

if (process.argv.includes("--vendor")) {
  const v = path.join(root, "www/js/vendor/supabase.js");
  if (!fs.existsSync(v)) ko("www/js/vendor/supabase.js absent (npm run vendor)");
  else { const t = fs.readFileSync(v, "utf8"); if (t.length < 50000 || !/createClient/.test(t)) ko("supabase.js invalide"); else ok("www/js/vendor/supabase.js présent (" + t.length + " octets)"); }
}
if (errs.length) { console.error("\n" + errs.length + " problème(s)."); process.exit(1); }
console.log("\nToutes les vérifications statiques sont passées.");
