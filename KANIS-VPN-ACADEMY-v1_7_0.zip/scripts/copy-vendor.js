// Copie supabase.js (version figée) dans www/js/vendor : l'APK ne dépend plus d'un CDN.
// Échoue (code 1) si la bibliothèque est absente ou ne ressemble pas au bundle navigateur attendu.
const fs = require("fs"), path = require("path");
const src = path.join(__dirname, "..", "node_modules", "@supabase", "supabase-js", "dist", "umd", "supabase.js");
const dst = path.join(__dirname, "..", "www", "js", "vendor", "supabase.js");
if (!fs.existsSync(src)) { console.error("supabase.js introuvable (" + src + ") : lance d'abord « npm install »."); process.exit(1); }
fs.mkdirSync(path.dirname(dst), { recursive: true });
fs.copyFileSync(src, dst);
const txt = fs.readFileSync(dst, "utf8"), size = fs.statSync(dst).size;
if (size < 50000 || !/createClient/.test(txt)) { console.error("Fichier copié invalide (" + size + " octets, createClient absent)."); process.exit(1); }
console.log("OK www/js/vendor/supabase.js (" + size + " octets)");
